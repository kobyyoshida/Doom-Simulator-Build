# Legal guidelines
Learn everything you need to know about Unity Ads' legal and compliance guidelines.

* [Publisher terms of service](LegalPublisherToS.md)
* [Advertiser terms of service](LegalAdvertiserToS.md)
* [Privacy policy](LegalPrivacy.md)
* [GDPR compliance](LegalGdpr.md)